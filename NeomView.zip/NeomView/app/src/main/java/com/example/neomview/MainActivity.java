package com.example.neomview;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PASSWORD_KEY = "password";
    private static final String FINGERPRINT_KEY = "fingerprint";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String password = prefs.getString(PASSWORD_KEY, "");
        boolean fingerprintEnabled = prefs.getBoolean(FINGERPRINT_KEY, false);

        final Intent i;

        if (!password.isEmpty() || fingerprintEnabled) {
            if (fingerprintEnabled) {
                // If fingerprint is enabled, start FingerprintAuthActivity
                i = new Intent(MainActivity.this, FingerprintAuthActivity.class);
            } else {
                // If password is saved but fingerprint is not enabled, ask for password
                i = new Intent(MainActivity.this, LockScreenActivity.class);
                i.putExtra("checkPassword", true);
            }
        } else {
            // If password is not saved and fingerprint is not enabled, go to MainActivity2
            i = new Intent(MainActivity.this, MainActivity2.class);
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(i);
                finish();
            }
        }, 2000);
    }
}
