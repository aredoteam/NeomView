package com.example.neomview;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.Task;

public class MainActivity3 extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private ReviewInfo reviewInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);

        // Initialize notification switch and set its checked state based on shared preferences
        Switch notificationSwitch = findViewById(R.id.notificationSwitch);
        notificationSwitch.setChecked(sharedPreferences.getBoolean("notificationsEnabled", true));

        // Set listener to enable/disable notifications when switch is toggled
        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("notificationsEnabled", isChecked);
            editor.apply();
            // Enable or disable notifications based on isChecked value
        });

        // Initialize review manager
        ReviewManager reviewManager = ReviewManagerFactory.create(this);

        // Request review flow
        Task<ReviewInfo> request = reviewManager.requestReviewFlow();
        request.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Get ReviewInfo object
                reviewInfo = task.getResult();
            } else {
                // There was some problem, continue anyway
                // (for example, the user is not eligible to review)
            }
        });

        TextView reviewTextView = findViewById(R.id.reviewTextView);
        reviewTextView.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.example.neomview"));
            startActivity(browserIntent);
        });


        // Initialize views and set click listeners
        TextView profileTextView = findViewById(R.id.profileTextView);
        profileTextView.setOnClickListener(v -> goToMainActivity4());

        TextView myorderTextView = findViewById(R.id.myorderTextView);
        myorderTextView.setOnClickListener(v -> goToMainActivity5());

        TextView mycartTextView = findViewById(R.id.mycartTextView);
        mycartTextView.setOnClickListener(v -> goToMainActivity6());

        TextView trackingTextView = findViewById(R.id.trackingTextView);
        trackingTextView.setOnClickListener(v -> goToMainActivity6());

        TextView myadresstTextView = findViewById(R.id.myadressTextView);
        myadresstTextView.setOnClickListener(v -> goToMainActivity11());

        TextView changepasswordTextView = findViewById(R.id.changepassword);
        changepasswordTextView.setOnClickListener(v -> goToMainActivity7());

        TextView addpasswordTextView = findViewById(R.id.addpassword);
        addpasswordTextView.setOnClickListener(v -> goToAddPasswordActivity());

        TextView addfingerprintTextView = findViewById(R.id.addfingerprint);
        addfingerprintTextView.setOnClickListener(v -> goFingerprintACTIVTY());

        TextView qrscannerTextView = findViewById(R.id.qrscanner);
        qrscannerTextView.setOnClickListener(v -> goToBarcodeScannerActivity());

        TextView supportTextView = findViewById(R.id.supportTextView);
        supportTextView.setOnClickListener(v -> goToMainActivity8());

        TextView privacyTextView = findViewById(R.id.privacyTextView);
        privacyTextView.setOnClickListener(v -> goToMainActivity9());

        // Initialize share button and set its click listener
        Button shareButton = findViewById(R.id.shareButton);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, "مشاركة تطبيقي");
                shareIntent.putExtra(Intent.EXTRA_TEXT, "تحقق من هذا التطبيق الرائع! رابط التطبيق: https://example.com");
                startActivity(Intent.createChooser(shareIntent, "مشاركة التطبيق"));
            }
        });
    }

    private void goToMainActivity4() {
        Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
        startActivity(intent);
    }

    private void goToMainActivity5() {
        Intent intent = new Intent(MainActivity3.this, MainActivity5.class);
        startActivity(intent);
    }

    private void goToMainActivity6() {
        Intent intent = new Intent(MainActivity3.this, MainActivity6.class);
        startActivity(intent);
    }

    private void goToMainActivity7() {
        Intent intent = new Intent(MainActivity3.this, MainActivity7.class);
        startActivity(intent);
    }

    private void goToMainActivity8() {
        Intent intent = new Intent(MainActivity3.this, MainActivity8.class);
        startActivity(intent);
    }

    private void goToMainActivity9() {
        Intent intent = new Intent(MainActivity3.this, MainActivity9.class);
        startActivity(intent);
    }

    private void goToAddPasswordActivity() {
        Intent intent = new Intent(MainActivity3.this, AddPasswordActivity.class);
        startActivity(intent);
    }

    private void goFingerprintACTIVTY() {
        Intent intent = new Intent(MainActivity3.this, FingerprintAuthActivity.class);
        startActivity(intent);
    }

    private void goToBarcodeScannerActivity() {
        Intent intent = new Intent(MainActivity3.this, BarcodeScannerActivity.class);
        startActivity(intent);
    }

    private void goToMainActivity11() {
        Intent intent = new Intent(MainActivity3.this, MainActivity11.class);
        startActivity(intent);
    }
}
