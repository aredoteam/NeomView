package com.example.neomview;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LockScreenActivity extends AppCompatActivity {

    private EditText passwordEditText;
    private Button unlockButton;

    // Key for password in shared preferences
    private static final String PASSWORD_KEY = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_screen);

        passwordEditText = findViewById(R.id.passwordEditText);
        unlockButton = findViewById(R.id.unlockButton);

        unlockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = passwordEditText.getText().toString();

                // Get saved password from shared preferences
                SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
                String savedPassword = prefs.getString(PASSWORD_KEY, "");

                // Check if password matches saved password
                if (password.equals(savedPassword)) {
                    Intent i = new Intent(LockScreenActivity.this, MainActivity3.class);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(LockScreenActivity.this, "Wrong password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
