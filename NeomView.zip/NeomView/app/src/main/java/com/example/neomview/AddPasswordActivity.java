package com.example.neomview;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddPasswordActivity extends AppCompatActivity {
    // Key for password in shared preferences
    private static final String PASSWORD_KEY = "password";

    private EditText newPasswordEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_password);

        newPasswordEditText = findViewById(R.id.newPasswordEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = newPasswordEditText.getText().toString();

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(AddPasswordActivity.this, "Please enter a password", Toast.LENGTH_SHORT).show();
                } else {
                    // Save password to shared preferences
                    SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString(PASSWORD_KEY, password);
                    editor.apply();

                    Toast.makeText(AddPasswordActivity.this, "Password saved", Toast.LENGTH_SHORT).show();

                    // Wait for 3 seconds before going to MainActivity3 to simulate a delay
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            String savedPassword = prefs.getString(PASSWORD_KEY, "");
                            if (TextUtils.isEmpty(savedPassword)) {
                                // No password saved, go back to AddPasswordActivity
                                Toast.makeText(AddPasswordActivity.this, "Please save a password first", Toast.LENGTH_SHORT).show();
                            } else {
                                // Password saved, go to MainActivity3
                                Intent intent = new Intent(AddPasswordActivity.this, MainActivity3.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    }, 3000);
                }
            }
        });
    }
}
