package com.example.neomview;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity5 extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main5);
        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (!isNetworkAvailable()) {
                    webView.loadUrl("file:///android_asset/no_connection.html");
                }
            }
        });

        if (isNetworkAvailable()) {
            webView.loadUrl("https://www.google.com");
        } else {
            webView.loadUrl("file:///android_asset/no_connection.html");
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        if (isNetworkAvailable()) {
                            webView.loadUrl("https://www.google.com");
                        } else {
                            webView.loadUrl("file:///android_asset/no_connection.html");
                        }
                        break;
                    case R.id.navigation_dashboard:
                        if (isNetworkAvailable()) {
                            webView.loadUrl("https://www.google.com");
                        } else {
                            webView.loadUrl("file:///android_asset/no_connection.html");
                        }
                        break;
                    case R.id.navigation_favourite:
                        if (isNetworkAvailable()) {
                            webView.loadUrl("https://www.google.com");
                        } else {
                            webView.loadUrl("file:///android_asset/no_connection.html");
                        }
                        break;
                    case R.id.navigation_heart:
                        if (isNetworkAvailable()) {
                            webView.loadUrl("https://www.google.com");
                        } else {
                            webView.loadUrl("file:///android_asset/no_connection.html");
                        }
                        break;
                    case R.id.navigation_notifications:
                        Intent intent = new Intent(MainActivity5.this, MainActivity3.class);
                        startActivity(intent);
                        break;
                }
                return true;
            }
        });
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }
}
