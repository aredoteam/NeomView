package com.example.neomview;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class BarcodeScannerActivity extends AppCompatActivity {

    private Button scanButton, openLinkButton, copyLinkButton;
    private static final int BARCODE_READER_REQUEST_CODE = 1;
    private String barcodeValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode_scanner);

        // Lock screen orientation to portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        scanButton = findViewById(R.id.scan_button);
        openLinkButton = findViewById(R.id.open_link_button);
        copyLinkButton = findViewById(R.id.copy_link_button);

        openLinkButton.setEnabled(false);
        copyLinkButton.setEnabled(false);

        scanButton.setOnClickListener(view -> openBarcodeReader());
        openLinkButton.setOnClickListener(view -> openLinkInApp());
        copyLinkButton.setOnClickListener(view -> copyLinkToClipboard());
    }

    private void openBarcodeReader() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        integrator.setBarcodeImageEnabled(true);
        integrator.setOrientationLocked(false);
        integrator.setPrompt("Place a barcode inside the viewfinder rectangle to scan it.");

        integrator.setCaptureActivity(CustomCaptureActivity.class);
        integrator.initiateScan();
    }

    private void openLinkInApp() {
        if (barcodeValue != null && !barcodeValue.isEmpty()) {
            Intent intent = new Intent(BarcodeScannerActivity.this, WebViewActivity.class);
            intent.putExtra("url", barcodeValue);
            startActivity(intent);
        }
    }

    private void copyLinkToClipboard() {
        if (barcodeValue != null) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("barcodeValue", barcodeValue);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                // Handle scan cancel
                Toast.makeText(this, "Scan cancelled", Toast.LENGTH_SHORT).show();
            } else {
                // Handle successful scan
                barcodeValue = result.getContents();
                Toast.makeText(this, "Scanned: " + barcodeValue, Toast.LENGTH_SHORT).show();

                openLinkButton.setEnabled(true);
                copyLinkButton.setEnabled(true);
            }
        }
    }
}
